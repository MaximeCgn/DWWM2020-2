<?php
/**
 * @package   solo
 * @copyright Copyright (c)2014-2021 Nicholas K. Dionysopoulos / Akeeba Ltd
 * @license   GNU General Public License version 3, or later
 */

define('AKEEBABACKUP_PRO', '0');
define('AKEEBABACKUP_VERSION', '7.5.1');
define('AKEEBABACKUP_DATE', '2021-01-07');